<div>
    @php
       // print_r($diseasedetails);
    @endphp
    
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Preceding History</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AGN_history?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">ASOT Titre</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AGN_asot?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Highest Serum Creatinine</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AGN_high_secreat?? '' }}
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">GFR</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AGN_gfr?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Microscopic Haematauria</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AGN_micro_heamat?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Macroscopic Haematauria</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AGN_macro_heamat?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">C3</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AGN_c3?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">C4</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AGN_c4?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Blood Preasure</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AGN_bp?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">UOP</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AGN_uop?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Preceding History</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AGN_history?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Maximum Protenuria</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AGN_max_proten?? '' }}
       
    </p>
</div>

</div>
