<div>

<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Disease Etiology</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AKI_etio?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">RRT Needed</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AKI_rrt?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">IV Frusemide Infusion</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AKI_frusemide?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Biopsy Done</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->AKI_biopsy?? '' }}
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Notes</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->notes?? '' }}
       
    </p>
</div>
    <p class=" m-4 text-left text-blue-600">Last Record of Data :  {{$diseasedetails->created_at?? '' }} </p>

</div>
