<div>
    
<div class=" my-6  max-full p-6 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Disease Pattern</h5>
    </a>
    <p class="mb-3 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->NS_DiseasePattern?? '' }}
       
    </p>
</div>
    <div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Second Line Medication</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400">
        @php
            $vardata1 = json_decode($diseasedetails->NS_Second_line);
        @endphp
        <ul class="space-y-1 max-w-md list-disc list-inside text-gray-500 dark:text-gray-400">
        @foreach ($vardata1 as $vardataonce)
    <li>
       {{$vardataonce?? '' }}
    </li>
@endforeach
</ul>
       
    </p>
</div>

<div class=" my-6  max-full p-6 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Renal Biopsy</h5>
    </a>
    <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">{{$diseasedetails->NS_RenalBiopsy?? '' }}</p>
    @if ($diseasedetails->NS_RenalBiopsy == 'Yes')
            <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Biopsy Diagnosis {{$diseasedetails->NS_RenalBiopsy_Dx?? '' }}</p>

    @endif
</div>
    <div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Other Co-morbids</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400">
        @php
            $vardata2 = json_decode($diseasedetails->NS_OtherComorbids);
        @endphp
        <ul class="space-y-1 max-w-md list-disc list-inside text-gray-500 dark:text-gray-400">
        @foreach ($vardata2 as $vardataonce)
    <li>
       {{$vardataonce?? '' }}
    </li>
@endforeach
</ul>
       
    </p>
</div>



</div>
