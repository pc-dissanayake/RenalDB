<div>
    @php
        //print_r($diseasedetails);
    @endphp
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Disease Etiology</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->IGA_presentation?? '' }}
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Haematuria</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->IGA_heamat?? '' }}
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Last Serum Creatinine</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->IGA_last_secreat?? '' }}
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">EGFR</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->IGA_last_egfr?? '' }}
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Biopsy</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->IGA_biopsy?? '' }}
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Hypertension</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->IGA_hypertension?? '' }}
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Drugs</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400">
        @php
            $vardata = json_decode($diseasedetails->IGA_drugs);
        @endphp
        <ul class="space-y-1 max-w-md list-disc list-inside text-gray-500 dark:text-gray-400">
        @foreach ($vardata as $secondlinemed)
    <li>
       {{$secondlinemed?? '' }}
    </li>
@endforeach
</ul>
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">CKD</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->IGA_ckd?? '' }}
       
    </p>
</div>
</div>
