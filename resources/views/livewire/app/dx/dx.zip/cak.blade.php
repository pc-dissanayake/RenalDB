<div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Disease Etiology</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->CAK_DiseasePattern?? '' }}
       
    </p></div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Pyloplasty</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->CAK_pyeloplasty?? '' }}
       
    </p></div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Megaureter</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->CAK_megaureter?? '' }}
       
    </p></div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Vesicourethral Refux</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->CAK_VUR_type?? '' }}</p>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> Grade {{$diseasedetails->CAK_VUR_grade?? '' }}</p>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> Ureteric Implantation {{$diseasedetails->CAK_VUR_reimp?? '' }}</p>
    </div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Disease Etiology</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->CAK_VUR_type?? '' }}
       
    </p></div>
    <div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Last Serum Creatinine</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->CAK_last_secreat?? '' }}
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">EGFR</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->CAK_last_egfr?? '' }}
       
    </p>
</div>

<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">CKD Stage</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->CAK_ckd?? '' }}
       
    </p></div>
</div>
</div>
