<div>
<div>
    @php
        //print_r($diseasedetails);
    @endphp

    <div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Diagnosis</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400">
        @php
            $vardata = json_decode($diseasedetails->SLE_diagnosis);
        @endphp
        <ul class="space-y-1 max-w-md list-disc list-inside text-gray-500 dark:text-gray-400">
        @foreach ($vardata as $secondlinemed)
    <li>
       {{$secondlinemed?? '' }}
    </li>
@endforeach
</ul>
       
    </p>
</div>

<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Drugs</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400">
        @php
            $vardata = json_decode($diseasedetails->SLE_drugsused);
        @endphp
        <ul class="space-y-1 max-w-md list-disc list-inside text-gray-500 dark:text-gray-400">
        @foreach ($vardata as $secondlinemed)
    <li>
       {{$secondlinemed?? '' }}
    </li>
@endforeach
</ul>
       
    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Last Serum Creatinine</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->SLE_last_secreat?? '' }}
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">EGFR</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->SLE_last_egfr?? '' }}
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">CKD Stage</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->SLE_ckd?? '' }}
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Renal Biopsy</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->SLE_biopsy?? '' }}
       
    </p>
</div>
</div>
</div>
