<div>
    
<div class=" my-6  max-full p-6 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Etiology</h5>
    </a>
    <p class="mb-3 font-base text-gray-700 dark:text-gray-400">{{$diseasedetails->CKD_etiology?? '' }}

    </p>
</div>
<div class=" my-6  max-full p-6 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Stage</h5>
    </a>
    <p class="mb-3 font-base text-gray-700 dark:text-gray-400">{{$diseasedetails->CKD_stage?? '' }}

    </p>
</div>
<div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Last Serum Creatinine</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->CKD_last_secreat?? '' }}
       
    </p>
</div><div class=" my-4  max-full p-2 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">EGFR</h5>
    </a>
    <p class="mb-2 font-base text-gray-700 dark:text-gray-400"> {{$diseasedetails->CKD_last_egfr?? '' }}
       
    </p>
</div>

<div class=" my-6  max-full p-6 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Donor Available</h5>
    </a>
    <p class="mb-3 font-base text-gray-700 dark:text-gray-400">{{$diseasedetails->CKD_donor?? '' }}

    </p>
</div>
<div class=" my-6  max-full p-6 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">RRT / CIC</h5>
    </a>
    <p class="mb-3 font-base text-gray-700 dark:text-gray-400">{{$diseasedetails->CKD_rrt?? '' }}

    </p>
</div>
<div class=" my-6  max-full p-6 bg-white border border-gray-200 rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Renal Transplant Plan</h5>
    </a>
    <p class="mb-3 font-base text-gray-700 dark:text-gray-400">{{$diseasedetails->CKD_transplant?? '' }}

    </p>
</div>


</div>
